from django.contrib import admin



from django.contrib import admin
from .models import Client, UserProfile, Category, SubCategory, Task, Assigny, TaskComment, Testing

# Register your models here.
admin.site.register(Client)

admin.site.register(UserProfile)

admin.site.register(Category)

admin.site.register(SubCategory)

admin.site.register(Task)

admin.site.register(Assigny)

admin.site.register(TaskComment)

admin.site.register(Testing)

