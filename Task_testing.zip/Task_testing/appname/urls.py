from django.conf.urls import url



from . import views

from django.conf import settings

from django.contrib.auth.views import LogoutView



urlpatterns = [
	url(r'^testing/$', views.post_list, name='testing'),
	url(r'^welcome/$', views.welcome, name='welcome'),
	url(r'^login/$', views.login_user, name='login'),
	url(r'^not_started/$', views.not_started_task, name='not_started'),
	url(r'^create_list/$', views.create_task, name='create_list'),
	url(r'^testing_form/$', views.Testing_post, name='testing_form'),
	url(r'^testing_display/$', views.testing_display, name='testing_display'),
	url(r'^(?P<pk>\d+)/detail/$', views.TaskDetailView.as_view(),
        name='detail'),
    url(r'^(?P<pk>\d+)/update/$', views.TaskupdateView.as_view(),
        name='update'),
    url(r'^category_dropdown/$', views.category_dropdown, name='category_dropdown'),

    url(r'^register/$', views.Register, name='register'),
    url(r'^Test_two_form/$', views.Test_two_form, name='Test_two_form'),

	
]