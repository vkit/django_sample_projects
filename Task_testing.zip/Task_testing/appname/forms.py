from django import forms
from .models import Task, Assigny, Client, Category, SubCategory, TaskComment, UserProfile,Testing
from django.contrib.auth.models import User
from .approval_status import APPROVAL
from django.conf import settings

GENDER = (
    ('MALE','MALE'),
    ('FEMALE',"FEMALE"),
)

CATEGORY_STATUS = (
    ('ACTIVE', 'ACTIVE'),
    ('INACTIVE', 'INACTIVE')
)



class TaskForm(forms.ModelForm):
    client = forms.ModelChoiceField(required=True, queryset=Client.objects.filter(ative_flag='ACTIVE'))
    task_detail = forms.CharField(required=True, widget=forms.Textarea)
    notice_reference = forms.CharField(label='Notice Reference', 
                    widget=forms.TextInput(attrs={'placeholder': 'Enter Notice Reference'}))
    due_date = forms.DateField(required=True, input_formats=settings.DATE_INPUT_FORMATS, widget=forms.DateInput(attrs={'placeholder': 'DD-MM-YYYY', 'required': 'True'}))
    assigny = forms.ModelChoiceField(required=True, queryset=Assigny.objects.all())
    reviwed_by = forms.ModelChoiceField(required=True, queryset=UserProfile.objects.exclude(user_type=1))
    category = forms.ModelChoiceField(required=True, queryset=Category.objects.filter(category_status='ACTIVE'))
    # client = forms
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)

    class Meta:
        model = Task
        fields = (
            'client', 
            'category', 
            # 'sub_category', 
            'task_detail',
            'notice_reference',
            'due_date',
            'assigny',
        )


class TestingForm(forms.ModelForm):
    # name = forms.CharField(required=True)
    address = forms.CharField(required=True, widget=forms.Textarea)
    gender = forms.ChoiceField(choices=GENDER, widget=forms.RadioSelect)
    email = forms.EmailField(required=True)
    Avg = forms.IntegerField(required=True)
    created_at = forms.DateField(widget = forms.SelectDateWidget) 

    class Meta:
        model = Testing
        fields = (
            'name',
            'address',
            'email',
            'Avg',
            'image',
            'gender',
            'created_at',
        )

class UpdateTaskForm(forms.ModelForm):
    name = forms.CharField(required=True)
    address = forms.CharField(required=True, widget=forms.Textarea)

    class Meta:
        model = Testing
        fields = (
            'name',
            'address',
            'email',
            'Avg'
        )


class CategoryForm(forms.ModelForm):
    category_name = forms.CharField(required=True)
    category_status = forms.ChoiceField(choices=CATEGORY_STATUS, widget=forms.RadioSelect)

    class Meta:
        model = Category
        fields = (
            'category_name',
            'category_status',
        )

class SubCategoryForm(forms.ModelForm):
    sub_category_name = forms.CharField(required=True)
    sub_category_status = forms.ChoiceField(choices=CATEGORY_STATUS, widget=forms.RadioSelect)

    class Meta:
        model = SubCategory
        fields = (
            'sub_category_name',
            'sub_category_status',
        )
