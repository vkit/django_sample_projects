# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django.contrib.auth.models import User

from django.utils import timezone

from .approval_status import APPROVAL

# Create your models here.


ACTIVE_FLAG = (
    ('ACTIVE', 'ACTIVE'),
    ('INACTIVE', 'INACTIVE'),
    ('DORAMANT', 'DORAMANT'),
)

CATEGORY_STATUS = (
    ('ACTIVE', 'ACTIVE'),
    ('INACTIVE', 'INACTIVE')
)

CLIENT_TYPE = (
    ('PROPRIETORY', 'PROPRIETORY'),
    ('PARTENSHIP', 'PARTENSHIP'),
    ('HUF', 'HUF'),
    ('PRIVATE LTD', 'PRIVATE LTD'),
    ('PUBLIC LTD', 'PUBLIC LTD'),
    ('LLP', 'LLP'),
    ('TRUST', 'TRUST'),
    ('OTHERS', 'OTHERS'),

)

ASSIGNEE_STATUS = (
    ('NOT STARTED', 'NOT STARTED'),
    ('IN PROGRESS', 'IN PROGRESS'),
    ('SUBMITTED', 'SUBMITTED'),
    ('REVIEW REJECT', 'REVIEW REJECT'),
)

REVIEWER_STATUS = (
    ('PENDING', 'PENDING'),
    ('APPROVED', 'APPROVED'),
    ('REJECTED', 'REJECTED'),
)

TASK_STATUS = (
    ('OPEN', 'OPEN'),
    ('CLOSED', 'CLOSED'),
    ('OVERDUE', 'OVERDUE'),
)

TASK_STAGE = (
    ('NOT STARTED', 'NOT STARTED'),
    ('IN PROGRESS', 'IN PROGRESS'),
    ('UNDER REVIEW', 'UNDER REVIEW'),
    ('REVIEW CLEARED', 'REVIEW CLEARED'),
    ('REVIEW REJECT', 'REVIEW REJECT'),
    ('LATE ACTION APPROVED', 'LATE ACTION APPROVED'),
    ('EXTENSION SOUGHT', 'EXTENSION SOUGHT'),
    ('WAITING FOR CLIENT', 'WAITING FOR CLIENT')
)

GENDER = (
    ('MALE','MALE'),
    ('FEMALE',"FEMALE"),
)



class Testing(models.Model):
    name = models.CharField(max_length=50,unique=True, blank=True, null=True)
    email = models.EmailField(max_length=70, blank=True, null=True)
    user_name = models.ForeignKey(User,on_delete=models.CASCADE, blank=True, null=True)
    Avg = models.IntegerField(blank=True, null=True)
    image = models.ImageField(upload_to='images/',blank=True, null=True) 
    gender = models.CharField(max_length=40,choices=GENDER, default='MALE')
    address = models.CharField(max_length=50, blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.name


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, blank=True, null=True)

    user_type = models.IntegerField(default=1, help_text='1-assignee, 2-manager, 3-manger_admin, 4-super_user')

    designation = models.CharField(max_length=50, blank=True, null=True)

    display_name = models.CharField(max_length=50, blank=True, null=True)

    email = models.EmailField(max_length=70, blank=True, null=True)

    mobile_no = models.IntegerField(blank=True, null=True)

    active_flag = models.CharField(
        max_length=40,
        choices=ACTIVE_FLAG, default='ACTIVE'
    )

    created_at = models.DateTimeField(default=timezone.now)

    modified_at = models.DateTimeField(default=timezone.now)

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.user.username

# Missing one field contact person
class Client(models.Model):
    ative_flag = models.CharField(
        max_length=40,
        choices=ACTIVE_FLAG, default='ACTIVE'
    )
    client_name = models.CharField(max_length=100, blank=True, null=True)

    address = models.TextField(blank=True, null=True)

    city = models.CharField(max_length=100, blank=True, null=True)

    state = models.CharField(max_length=100, blank=True, null=True)

    phone_office = models.IntegerField(blank=True, null=True)

    mobile = models.IntegerField(blank=True, null=True)

    email1 = models.EmailField(max_length=70, null=True, blank=True)

    email2 = models.EmailField(max_length=70, null=True, blank=True)

    client_type = models.CharField(
        max_length=40,
        choices=CLIENT_TYPE, default='PROPRIETORY'
    )

    pan_no_entity = models.CharField(max_length=100, blank=True, null=True)

    tan_no = models.CharField(max_length=100, blank=True, null=True)

    gst_no = models.CharField(max_length=100, blank=True, null=True)

    created_by = models.ForeignKey(User,related_name = 'created_by',on_delete=models.CASCADE, blank=True, null=True)

    updated_by = models.ForeignKey(User,related_name = 'updated_by', on_delete=models.CASCADE, blank=True, null=True)

    created_at = models.DateTimeField(default=timezone.now)

    modified_at = models.DateTimeField(default=timezone.now)

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.client_name


class Category(models.Model):
    category_status = models.CharField(
        max_length=40,
        choices=CATEGORY_STATUS, default='ACTIVE'
    )

    category_name = models.CharField(max_length=100, blank=True, null=True)

    created_by = models.ForeignKey(User,related_name = 'category_created_by',on_delete=models.CASCADE, blank=True, null=True)

    updated_by = models.ForeignKey(User,related_name = 'category_updated_by', on_delete=models.CASCADE, blank=True, null=True)

    created_at = models.DateTimeField(default=timezone.now)

    modified_at = models.DateTimeField(default=timezone.now)

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.category_name


class SubCategory(models.Model):
    sub_category_status = models.CharField(
        max_length=40,
        choices=CATEGORY_STATUS, default='ACTIVE'
    )

    category = models.ForeignKey(Category, related_name='category',on_delete=models. CASCADE, blank=True, null=True)

    sub_category_name = models.CharField(max_length=100, blank=True, null=True)

    sub_created_by = models.ForeignKey(User,related_name = 'sub_category_created_by',on_delete=models.CASCADE, blank=True, null=True)

    sub_updated_by = models.ForeignKey(User,related_name = 'sub_category_updated_by', on_delete=models.CASCADE, blank=True, null=True)

    created_at = models.DateTimeField(default=timezone.now)

    modified_at = models.DateTimeField(default=timezone.now)

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.sub_category_name

class Assigny(models.Model):

    user = models.ForeignKey(User,on_delete=models. CASCADE, blank=True, null=True)

    created_at = models.DateTimeField(default=timezone.now)

    modified_at = models.DateTimeField(default=timezone.now)

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.user.username




# missing 3 fields late action approval, late action reason, late action aproval status
class Task(models.Model):

    client = models.ForeignKey(Client,on_delete=models. CASCADE, blank=True, null=True)

    category = models.ForeignKey(Category,on_delete=models. CASCADE, blank=True, null=True)

    sub_category = models.ForeignKey(SubCategory,on_delete=models. CASCADE, blank=True, null=True)

    task_detail = models.TextField(blank=True, null=True)

    notice_reference = models.CharField(max_length=50, blank=True, null=True)

    notice_date = models.DateField(default=timezone.now)

    due_date = models.DateField(default=timezone.now)

    expected_closure_date = models.DateField(default=timezone.now)

    assignee_status = models.CharField(
        max_length=40,
        choices=ASSIGNEE_STATUS, default='NOT STARTED'
    )

    reviewer_status = models.CharField(
        max_length=40,
        choices=REVIEWER_STATUS, default='PENDING'
    )

    assigny = models.ForeignKey(Assigny,related_name = 'assgny',on_delete=models.CASCADE, blank=True, null=True)

    reviwed_by = models.ForeignKey(UserProfile,related_name = 'reviwed_by',on_delete=models.CASCADE, blank=True, null=True)

    assigny_closure_date = models.DateField(default=timezone.now)

    reviwer_closure_date = models.DateField(default=timezone.now)

    task_status = models.CharField(
        max_length=40,
        choices=TASK_STATUS, default='OPEN'
    )

    task_stage = models.CharField(
        max_length=40,
        choices=TASK_STAGE, default='NOT STARTED'
    )

    comments = models.TextField(blank=True, null=True)

    task_created_by = models.ForeignKey(User,on_delete=models. CASCADE, related_name='task_created_by', blank=True, null=True)

    task_updated_by = models.ForeignKey(User,on_delete=models. CASCADE, related_name='task_updated_by', blank=True, null=True)

    late_approval_reason = models.TextField(blank=True, null=True)

    late_action_approval = models.CharField(max_length=50, choices=APPROVAL, blank=True, null=True)

    late_action_approval_status = models.CharField(max_length=50, choices=REVIEWER_STATUS, default='PENDING')

    created_at = models.DateTimeField(default=timezone.now)

    modified_at = models.DateField(default=timezone.now)

    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-modified_at']

    def task_comment_stage_func(self):
        try:
            return self.comment_task.last().task_comment_stage
        except:
            return 'NOT STARTED'

    def __unicode__(self):
        return self.task_detail

    


    


# class TaskHistoryCommnt(models.Model):
    
#     user = models.ForeignKey(User, blank=True, null=True)

#     task = models.ForeignKey(Task, related_name='task', blank=True, null=True)

#     task_modified_by = models.ForeignKey(User, related_name='task_modified_by', blank=True, null=True)

#     task_history_stage = models.CharField(
#         max_length=40,
#         choices=TASK_STAGE, default='NOT STARTED'
#     )

#     task_history_comments = models.TextField(blank=True, null=True)



class TaskComment(models.Model):
    user = models.ForeignKey(User,on_delete=models. CASCADE, blank=True, null=True)

    comment_task = models.ForeignKey(Task,on_delete=models. CASCADE, related_name='comment_task', blank=True, null=True)

    task_comment_update_by = models.ForeignKey(User,on_delete=models. CASCADE, related_name='task_comment_update_by', blank=True, null=True)

    task_comment_stage = models.CharField(
        max_length=40,
        choices=TASK_STAGE, default='NOT STARTED'
    )

    task_comment = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(default=timezone.now)

    modified_at = models.DateTimeField(default=timezone.now)

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.task_comment_stage







# Create your models here.
