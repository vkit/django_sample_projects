APPROVAL = (
    ('Yes', 'Yes'),
    ('No', 'No')
)
