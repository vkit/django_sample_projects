from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.shortcuts import HttpResponseRedirect
from django.contrib.auth.models import User
from django.contrib.auth.mixins import LoginRequiredMixin
from datetime import date, timedelta

from django.views.generic import ListView, View, DetailView

from django.contrib import messages
from .models import UserProfile,Task,Testing,SubCategory,Category
from .forms import TaskForm,TestingForm,UpdateTaskForm,CategoryForm,SubCategoryForm


def welcome(request):
	return render(request,'welcome.html')

# Create your views here
def post_list(request):
	return render(request,'test.html')


def login_user(request):
	try:
		if request.method == 'POST':
			username = request.POST['username']
			password = request.POST['password']

			user = authenticate(username=username, password=password)
			if user is not None:
				if user.is_active:
					login(request, user)
					userprofile = UserProfile.objects.get(user=user)
					return HttpResponseRedirect('/appname/welcome/')
				else:
					return HttpResponseRedirect('/appname/login/')
			else:
				messages.error(request, 'Oops!Username and Password were Incorect! Please check Your Username and Password')
				return HttpResponseRedirect('/appname/login/')
		return render(request, 'registration/login.html')
	except UserProfile.DoesNotExist:
		print("User profile query does not exists")
		messages.error(request, 'Oops!Username and Password were Incorect! Please check Your Username and Password')
		return HttpResponseRedirect('/appname/login/')



def Register(request):
	try:
		if request.method == 'POST':
			username = request.POST['username']
			password = request.POST['password']
			if User.objects.filter(username=username).exists():
				print("Username already exists")
				messages.error(request, 'Oops!Username and Password were Incorect! Please check Your Username and Password')
				return HttpResponseRedirect('/appname/register/')
			else:
				user = User.objects.create_user(username=username,password=password)
				print("user created Successfully")
				messages.success(request, 'User is created Successfully')
				return HttpResponseRedirect('/appname/login/')
		return render(request,'registration/register.html')
	except Exception as e:
		print(e)



def Create_Task(request):
	form = TaskForm(request.POST)
	if form.is_valid():
		instance = form.instance
		instance.task_created_by = 'raghu'
		instance.save()
		form.save()
		messages.success(request, 'Well done!Your Task is Submitted Succesfully.')
		return HttpResponseRedirect('/appname/create_task/')
	else:
		form = TaskForm()
	return render(request, 'task_list.html', {'form': form})


def not_started_task(request):
	lis = []
	context = {}
	task_lists = Task.objects.filter(is_active=True)
	for task_list in task_lists:
		if task_list.assignee_status=='NOT STARTED':
			lis.append(task_list)
	print(len(lis))
	return render(request,'not_started_task.html',{'not_started_task':len(lis)})


def create_task(request):
	form = TaskForm(request.POST)

	if form.is_valid():
		instance = form.instance
		# instance.assignee_status = 'SUBMITTED'
		instance.save()
		form.save()
		print(form)
		messages.success(request, 'Well done!Your Task is Submitted Succesfully.')
		return HttpResponseRedirect('/appname/create_list/')
	else:
		form = TaskForm()
	return render(request, 'task_list.html', {'form': form})


def Testing_post(request):
	user = request.user
	if request.method =='POST':
		name = request.POST['name']

	form = TestingForm(request.POST, request.FILES or None)
	if form.is_valid():
		instance = form.instance
		print(instance.email)
		instance.user_name = user
		instance.name = name
		instance.save()
		form.save()
		messages.success(request, 'Well done!Your Task is Submitted Succesfully.')
		return HttpResponseRedirect('/appname/testing_form/')
	else:
		form = TestingForm()
	return render(request, 'testing_form.html', {'form': form})

def testing_display(request):
	user = request.user

	posts = Testing.objects.all()

	return render(request, 'testing_form.html', {'posts':posts})

class TaskDetailView(LoginRequiredMixin, DetailView):
    template_name = 'task_update.html'
    model = Testing

    def get_context_data(self, **kwargs):
        context = super(TaskDetailView, self).get_context_data(**kwargs)
        context['post'] = Testing.objects.get(pk=self.kwargs.get('pk'))
        context['form1'] = UpdateTaskForm(instance=context['post'])
        context['today_date'] = date.today()
        return context

class TaskupdateView(LoginRequiredMixin, View):

    def post(self, request, *args, **kwargs):
        user = request.user
        post = Testing.objects.get(pk=self.kwargs.get('pk'))
        form1 = UpdateTaskForm(request.POST, instance=post)
        if form1.is_valid():
        	instance = form1.instance
        	instance.save()
        	form1.save()
        	messages.success(
        	request, 'Well done!Your Task is updated succesfully.')
        else:
            print(form1.errors)
        return HttpResponseRedirect(
            '/appname/{0}/detail/'.format(post.id))
import json

def category_dropdown(request):
	dict = {}
	print("hi how are yoyr")
	subcategory_list = SubCategory.objects.filter(category__category_name__startswith='category').values()
	print(subcategory_list)
	# print(json.dumps(subcategory_list))
	messages.success(request, 'Well Done! Client Data Added Succesfully')
	return render(request, 'drop_down.html')


def Test_two_form(request):
    if request.method =='POST':
        form1 = CategoryForm(request.POST)
        form2 = SubCategoryForm(request.POST)
        if form1.is_valid() and form2.is_valid():
        	instance1 = form1.instance
        	instance2 = form2.instance

        	form1.save()
        	print(instance1.category_name)
        	try:
	        	cate_variable = Category.objects.get(category_name=instance1.category_name)
	        except Category.DoesNotExist:
	        	print("Category does not exists")

        	print("This is the result", cate_variable)
        	instance2.category = cate_variable
        	instance1.save()
        	instance2.save()
        	form2.save()
        	messages.success(request, 'Well done!Your Task is Submitted Succesfully.')
        	return HttpResponseRedirect('/appname/Test_two_form/')
    else:
        form1 = CategoryForm()
        form2 = SubCategoryForm()
    return render(request, 'test_two_form.html', {'form1':form1, 'form2':form2})